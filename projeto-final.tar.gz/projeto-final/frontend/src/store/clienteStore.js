import { create } from 'zustand';
import { persist } from 'zustand/middleware';

const useClienteStore = create(
  persist(
    (set, get) => ({
      clientes: [
        { id: 1, nome: 'João Silva', cpfCnpj: '123.456.789-00', telefone: '(41) 99999-0001', email: 'joao@email.com', endereco: 'Rua A, 123' },
        { id: 2, nome: 'Maria Santos', cpfCnpj: '987.654.321-00', telefone: '(41) 99999-0002', email: 'maria@email.com', endereco: 'Rua B, 456' }
      ],
      
      addCliente: (cliente) => set((state) => ({
        clientes: [...state.clientes, { ...cliente, id: Date.now() }]
      })),
      
      updateCliente: (id, updatedCliente) => set((state) => ({
        clientes: state.clientes.map(c => c.id === id ? { ...c, ...updatedCliente } : c)
      })),
      
      deleteCliente: (id) => set((state) => ({
        clientes: state.clientes.filter(c => c.id !== id)
      })),
      
      getClienteById: (id) => {
        return get().clientes.find(c => c.id === id);
      },
      
      searchClientes: (searchTerm) => {
        const clientes = get().clientes;
        if (!searchTerm) return clientes;
        
        const term = searchTerm.toLowerCase();
        return clientes.filter(c => 
          c.nome.toLowerCase().includes(term) ||
          c.cpfCnpj.includes(term) ||
          c.email.toLowerCase().includes(term)
        );
      }
    }),
    {
      name: 'cliente-storage',
    }
  )
);

export default useClienteStore;
