import { create } from 'zustand';
import { persist } from 'zustand/middleware';

const usePagamentoStore = create(
  persist(
    (set, get) => ({
      pagamentos: [
        { id: 1, data: '2026-02-01', valor: 800.00, tipo: 'saida', descricao: 'Fornecedor XYZ', categoria: 'Compra', status: 'Pago' },
        { id: 2, data: '2026-02-05', valor: 1200.00, tipo: 'entrada', descricao: 'Reembolso', categoria: 'Outros', status: 'Pendente' }
      ],
      
      addPagamento: (pagamento) => set((state) => ({
        pagamentos: [...state.pagamentos, { ...pagamento, id: Date.now() }]
      })),
      
      updatePagamento: (id, updatedPagamento) => set((state) => ({
        pagamentos: state.pagamentos.map(p => p.id === id ? { ...p, ...updatedPagamento } : p)
      })),
      
      deletePagamento: (id) => set((state) => ({
        pagamentos: state.pagamentos.filter(p => p.id !== id)
      })),
      
      getTotalPagamentos: () => {
        return get().pagamentos
          .filter(p => p.tipo === 'saida')
          .reduce((sum, p) => sum + p.valor, 0);
      },
      
      getPagamentosPendentes: () => {
        return get().pagamentos.filter(p => p.status === 'Pendente');
      },
      
      getPagamentosByCategoria: () => {
        return get().pagamentos.reduce((acc, p) => {
          if (p.tipo === 'saida') {
            acc[p.categoria] = (acc[p.categoria] || 0) + p.valor;
          }
          return acc;
        }, {});
      }
    }),
    {
      name: 'pagamento-storage',
    }
  )
);

export default usePagamentoStore;
