import { create } from 'zustand';
import { persist } from 'zustand/middleware';

const useRecebimentoStore = create(
  persist(
    (set, get) => ({
      recebimentos: [
        { id: 1, vendaId: 1, data: '2026-02-01', valor: 1500.00, tipo: 'entrada', descricao: 'Pagamento Venda #1', categoria: 'Venda' },
        { id: 2, vendaId: null, data: '2026-02-02', valor: 500.00, tipo: 'saida', descricao: 'Devolução Cliente', categoria: 'Devolução' }
      ],
      
      addRecebimento: (recebimento) => set((state) => ({
        recebimentos: [...state.recebimentos, { ...recebimento, id: Date.now() }]
      })),
      
      updateRecebimento: (id, updatedRecebimento) => set((state) => ({
        recebimentos: state.recebimentos.map(r => r.id === id ? { ...r, ...updatedRecebimento } : r)
      })),
      
      deleteRecebimento: (id) => set((state) => ({
        recebimentos: state.recebimentos.filter(r => r.id !== id)
      })),
      
      getTotalEntradas: () => {
        return get().recebimentos
          .filter(r => r.tipo === 'entrada')
          .reduce((sum, r) => sum + r.valor, 0);
      },
      
      getTotalSaidas: () => {
        return get().recebimentos
          .filter(r => r.tipo === 'saida')
          .reduce((sum, r) => sum + r.valor, 0);
      },
      
      getRecebimentosByCategoria: () => {
        return get().recebimentos.reduce((acc, r) => {
          if (r.tipo === 'entrada') {
            acc[r.categoria] = (acc[r.categoria] || 0) + r.valor;
          }
          return acc;
        }, {});
      }
    }),
    {
      name: 'recebimento-storage',
    }
  )
);

export default useRecebimentoStore;
