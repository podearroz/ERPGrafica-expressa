import { create } from 'zustand';
import { persist } from 'zustand/middleware';

const useVendaStore = create(
  persist(
    (set, get) => ({
      vendas: [
        { id: 1, clienteId: 1, data: '2026-02-01', valor: 1500.00, produtos: 'Produto A, Produto B', status: 'Pago', formaPagamento: 'PIX' },
        { id: 2, clienteId: 2, data: '2026-02-03', valor: 2300.00, produtos: 'Produto C', status: 'Pendente', formaPagamento: 'Boleto' }
      ],
      
      addVenda: (venda) => set((state) => ({
        vendas: [...state.vendas, { ...venda, id: Date.now() }]
      })),
      
      updateVenda: (id, updatedVenda) => set((state) => ({
        vendas: state.vendas.map(v => v.id === id ? { ...v, ...updatedVenda } : v)
      })),
      
      deleteVenda: (id) => set((state) => ({
        vendas: state.vendas.filter(v => v.id !== id)
      })),
      
      getVendaById: (id) => {
        return get().vendas.find(v => v.id === id);
      },
      
      getVendasByCliente: (clienteId) => {
        return get().vendas.filter(v => v.clienteId === clienteId);
      },
      
      getTotalVendas: () => {
        return get().vendas.reduce((sum, v) => sum + v.valor, 0);
      },
      
      getVendasPendentes: () => {
        return get().vendas.filter(v => v.status === 'Pendente');
      }
    }),
    {
      name: 'venda-storage',
    }
  )
);

export default useVendaStore;
